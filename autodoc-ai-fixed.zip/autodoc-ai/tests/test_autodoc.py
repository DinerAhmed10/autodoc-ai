"""Tests for AutoDoc-AI"""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from autodoc.scanner import CodeScanner
from autodoc.writer import DocWriter
import tempfile
import os


# ─── Scanner Tests ────────────────────────────────────────────────────────────

def test_scanner_finds_python_files(tmp_path):
    (tmp_path / "main.py").write_text("def hello(): pass")
    (tmp_path / "utils.py").write_text("def util(): pass")

    scanner = CodeScanner(tmp_path)
    result = scanner.scan()

    assert result["lang"] == "python"
    assert result["file_count"] == 2
    assert any(f["path"] == "main.py" for f in result["files"])


def test_scanner_ignores_node_modules(tmp_path):
    (tmp_path / "index.js").write_text("const x = 1;")
    nm = tmp_path / "node_modules"
    nm.mkdir()
    (nm / "lib.js").write_text("module.exports = {};")

    scanner = CodeScanner(tmp_path)
    result = scanner.scan()

    assert result["file_count"] == 1


def test_scanner_forced_lang(tmp_path):
    (tmp_path / "app.py").write_text("x = 1")
    scanner = CodeScanner(tmp_path, forced_lang="typescript")
    result = scanner.scan()
    assert result["lang"] == "typescript"


def test_scanner_detects_metadata(tmp_path):
    (tmp_path / "main.py").write_text("x = 1")
    (tmp_path / "README.md").write_text("# My Project")
    (tmp_path / "requirements.txt").write_text("requests\nflask")

    scanner = CodeScanner(tmp_path)
    result = scanner.scan()

    assert "README.md" in result["metadata"]
    assert "requirements.txt" in result["metadata"]


def test_scanner_empty_directory(tmp_path):
    scanner = CodeScanner(tmp_path)
    result = scanner.scan()

    assert result["file_count"] == 0
    assert result["lang"] == "unknown"


# ─── Writer Tests ─────────────────────────────────────────────────────────────

def test_writer_markdown(tmp_path):
    writer = DocWriter(output_dir=str(tmp_path / "docs"), fmt="markdown")
    docs = [
        {"filename": "README.md", "content": "# Hello", "type": "readme"},
        {"filename": "API.md", "content": "# API", "type": "api"},
    ]
    written = writer.write(docs)

    assert len(written) == 2
    assert (tmp_path / "docs" / "README.md").exists()
    assert (tmp_path / "docs" / "API.md").read_text() == "# API"


def test_writer_html(tmp_path):
    writer = DocWriter(output_dir=str(tmp_path / "docs"), fmt="html")
    docs = [
        {"filename": "README.md", "content": "# Hello World", "type": "readme"},
    ]
    writer.write(docs)

    html_file = tmp_path / "docs" / "README.html"
    assert html_file.exists()
    content = html_file.read_text()
    assert "<h1>" in content
    assert "Hello World" in content


def test_writer_json(tmp_path):
    import json
    writer = DocWriter(output_dir=str(tmp_path / "docs"), fmt="json")
    docs = [
        {"filename": "README.md", "content": "# Hello", "type": "readme"},
        {"filename": "API.md", "content": "# API", "type": "api"},
    ]
    written = writer.write(docs)

    assert len(written) == 1
    data = json.loads(Path(written[0]).read_text())
    assert "README.md" in data
    assert "API.md" in data


def test_writer_creates_output_dir(tmp_path):
    deep = tmp_path / "a" / "b" / "c"
    writer = DocWriter(output_dir=str(deep), fmt="markdown")
    docs = [{"filename": "README.md", "content": "hi", "type": "readme"}]
    writer.write(docs)
    assert deep.exists()


# ─── Integration-like Tests ───────────────────────────────────────────────────

def test_full_scan_and_write(tmp_path):
    """Scan a temp project and write markdown docs (no AI call)."""
    src = tmp_path / "myproject"
    src.mkdir()
    (src / "main.py").write_text("def greet(name): return f'Hello {name}'")
    (src / "utils.py").write_text("def add(a, b): return a + b")

    scanner = CodeScanner(src)
    result = scanner.scan()
    assert result["file_count"] == 2

    docs = [{"filename": "README.md", "content": f"# {result['project_name']}", "type": "readme"}]
    out = tmp_path / "docs"
    writer = DocWriter(output_dir=str(out), fmt="markdown")
    written = writer.write(docs)

    assert (out / "README.md").read_text() == "# myproject"
