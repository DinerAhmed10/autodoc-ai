# 🤖 AutoDoc-AI

> **Generate beautiful documentation for any codebase in 30 seconds using AI.**

[![PyPI version](https://badge.fury.io/py/autodoc-ai.svg)](https://pypi.org/project/autodoc-ai/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![CI](https://github.com/yourusername/autodoc-ai/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/autodoc-ai/actions)
[![Downloads](https://pepy.tech/badge/autodoc-ai)](https://pepy.tech/project/autodoc-ai)

Point AutoDoc-AI at any project directory and it instantly generates:
- 📄 **README.md** — Professional, full-featured readme
- 📚 **API.md** — Complete API reference with examples
- 📝 **CONTRIBUTING.md** — Contribution guidelines
- 📋 **CHANGELOG.md** — Formatted changelog template
- 💬 **Inline comments** — AI-added comments to source files

Works with **Python, JavaScript, TypeScript, Go, Rust, Java, Ruby, PHP, C/C++, Kotlin, Swift** and more.

---

## 🚀 Quick Start

```bash
# Install
pip install autodoc-ai

# Set your API key (free at console.anthropic.com)
export ANTHROPIC_API_KEY=your-key-here

# Document your project
autodoc .
```

That's it. Your `/docs` folder is ready. ✅

---

## ✨ Features

- **🌍 Multi-language** — Detects and supports 15+ programming languages automatically
- **📁 Smart scanning** — Ignores `node_modules`, `.git`, `__pycache__`, and other noise
- **🎨 Multiple output formats** — Markdown, HTML site, or JSON
- **💬 Inline comments** — Adds helpful comments to complex code (opt-in)
- **⚡ Fast** — Documents a 50-file project in under 60 seconds
- **🔧 Configurable** — Control what gets generated and where it goes
- **🤖 Powered by Claude** — Uses Anthropic's Claude for intelligent analysis

---

## 📦 Installation

```bash
pip install autodoc-ai
```

**Requirements:**
- Python 3.9+
- An [Anthropic API key](https://console.anthropic.com) (free tier available)

---

## 📖 Usage

### Basic Usage

```bash
# Document current directory
autodoc .

# Document a specific project
autodoc /path/to/my-project

# Custom output directory
autodoc . --output ./documentation
```

### Output Formats

```bash
# Markdown files (default)
autodoc . --format markdown

# HTML documentation site
autodoc . --format html

# Single JSON file (good for CI/CD integration)
autodoc . --format json
```

### Selective Generation

```bash
# Only generate README (fastest)
autodoc . --readme-only

# Add inline comments to source files
autodoc . --comments

# Preview without writing files
autodoc . --dry-run
```

### Advanced Options

```bash
# Force language detection
autodoc . --lang typescript

# Use a specific Claude model
autodoc . --model claude-opus-4-5

# Verbose output
autodoc . --verbose

# Pass API key directly
autodoc . --api-key sk-ant-...
```

---

## 🎬 Demo

```
$ autodoc ./my-python-project

   _____          __         ________                   _____  .___
  /  _  \  __ ___/  |_  ____ \______ \   ____   ____  /  _  \ |   |
 ...

📁 Project: my-python-project
📝 Output:  ./docs
🎨 Format:  markdown

🔍 Scanning codebase...
   Found 23 files in python project

🤖 Generating documentation with AI...
   → Generating README.md...
   → Generating API documentation...
   → Generating CHANGELOG template...
   → Generating CONTRIBUTING.md...

💾 Writing documentation...

✅ Done! Generated 4 files:
   📄 docs/README.md
   📄 docs/API.md
   📄 docs/CHANGELOG.md
   📄 docs/CONTRIBUTING.md

🎉 Documentation saved to: ./docs
```

---

## ⚙️ Configuration

Create an `autodoc.toml` in your project root to set defaults:

```toml
[autodoc]
output = "./docs"
format = "markdown"
model = "claude-opus-4-5"

[autodoc.ignore]
dirs = ["tests", "examples", "benchmarks"]
files = ["conftest.py"]
```

---

## 🔌 Python API

Use AutoDoc-AI programmatically in your own scripts or CI/CD pipelines:

```python
from autodoc import CodeScanner, DocGenerator, DocWriter
from pathlib import Path

# Scan the project
scanner = CodeScanner(Path("./my-project"))
scan_result = scanner.scan()

# Generate docs with AI
generator = DocGenerator(api_key="your-api-key")
docs = generator.generate(scan_result, readme_only=True)

# Write to disk
writer = DocWriter(output_dir="./docs", fmt="markdown")
writer.write(docs)

print("Done!")
```

---

## 🔁 CI/CD Integration

Add to your GitHub Actions workflow to auto-update docs on every push:

```yaml
# .github/workflows/docs.yml
name: Update Documentation

on:
  push:
    branches: [main]

jobs:
  docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      
      - name: Install AutoDoc-AI
        run: pip install autodoc-ai

      - name: Generate docs
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: autodoc . --output ./docs --format markdown

      - name: Commit updated docs
        run: |
          git config --local user.email "github-actions[bot]@users.noreply.github.com"
          git config --local user.name "github-actions[bot]"
          git add docs/
          git diff --staged --quiet || git commit -m "docs: auto-update via AutoDoc-AI"
          git push
```

---

## 🤔 FAQ

**Q: Is my code sent to the cloud?**
A: Yes, code snippets are sent to Anthropic's API for analysis. Anthropic does not use API data to train models. See [Anthropic's privacy policy](https://anthropic.com/privacy).

**Q: How much does it cost?**
A: AutoDoc-AI uses your own Anthropic API key. A typical project costs $0.01–0.10 to document. Anthropic offers free credits to new users.

**Q: Can I use it offline?**
A: Not currently. An internet connection is required for the AI features.

**Q: Does it work with private/closed-source code?**
A: Yes. You control what gets scanned with the ignore settings.

**Q: Can I generate docs for just one file?**
A: Point it at a directory containing that file, or use the Python API directly.

---

## 🤝 Contributing

Contributions are very welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md).

```bash
# Dev setup
git clone https://github.com/yourusername/autodoc-ai
cd autodoc-ai
pip install -e ".[dev]"

# Run tests
pytest

# Submit a PR!
```

---

## 📄 License

MIT © AutoDoc-AI Contributors

---

<p align="center">
Made with ❤️ and powered by <a href="https://anthropic.com">Claude AI</a>
<br>
<strong>⭐ Star this repo if it saved you time!</strong>
</p>
