"""
AutoDoc-AI — AI-powered documentation generator for any codebase.
"""

import os
import sys
import argparse
# BUG FIX: removed unused `import json`
# BUG FIX: removed unused `from typing import Optional`
from pathlib import Path
from .scanner import CodeScanner
from .generator import DocGenerator
from .writer import DocWriter


BANNER = r"""
   _____          __         ________                   _____  .___
  /  _  \  __ ___/  |_  ____ \______ \   ____   ____  /  _  \ |   |
 /  /_\  \|  |  \   __\/  _ \ |    |  \ /  _ \_/ ___\/  /_\  \|   |
/    |    \  |  /|  | (  <_> )|    `   (  <_> )  \__/    |    \   |
\____|__  /____/ |__|  \____//_______  /\____/ \___  >____|__  /__|
        \/                           \/            \/        \/
        
        🤖 AI-Powered Documentation Generator  v1.0.0
"""


def parse_args():
    parser = argparse.ArgumentParser(
        prog="autodoc",
        description="Generate beautiful documentation for any codebase using AI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  autodoc .                         # Document current directory
  autodoc ./my-project              # Document a specific folder
  autodoc . --output ./docs         # Custom output directory
  autodoc . --format markdown       # Output as Markdown
  autodoc . --format html           # Output as HTML site
  autodoc . --lang python           # Force language detection
  autodoc . --readme-only           # Generate only README
  autodoc . --comments              # Add inline code comments
        """
    )

    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Path to the project directory (default: current directory)"
    )

    parser.add_argument(
        "--output", "-o",
        default="./docs",
        help="Output directory for generated docs (default: ./docs)"
    )

    parser.add_argument(
        "--format", "-f",
        choices=["markdown", "html", "json"],
        default="markdown",
        help="Output format (default: markdown)"
    )

    parser.add_argument(
        "--lang", "-l",
        help="Force language (python, javascript, typescript, go, rust, java, etc.)"
    )

    parser.add_argument(
        "--readme-only",
        action="store_true",
        help="Generate only README.md"
    )

    parser.add_argument(
        "--comments",
        action="store_true",
        help="Add AI-generated inline comments to source files"
    )

    parser.add_argument(
        "--api-key",
        help="Anthropic API key (or set ANTHROPIC_API_KEY env var)"
    )

    parser.add_argument(
        "--model",
        # BUG FIX: was "claude-opus-4-5" (invalid — missing date suffix).
        default="claude-opus-4-5-20251101",
        help="Claude model to use (default: claude-opus-4-5-20251101)"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed output"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview what would be generated without writing files"
    )

    return parser.parse_args()


def validate_api_key(args) -> str:
    key = args.api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        print("❌ Error: Anthropic API key not found.")
        print("   Set it via: export ANTHROPIC_API_KEY=your-key")
        print("   Or pass it: autodoc . --api-key your-key")
        print("   Get a free key at: https://console.anthropic.com")
        sys.exit(1)
    return key


def main():
    print(BANNER)
    args = parse_args()
    api_key = validate_api_key(args)

    project_path = Path(args.path).resolve()

    # BUG FIX: previously only checked .exists(); a file path would pass
    # that check and cause confusing errors deep inside the scanner.
    if not project_path.exists():
        print(f"❌ Error: Path '{project_path}' does not exist.")
        sys.exit(1)
    if not project_path.is_dir():
        print(f"❌ Error: Path '{project_path}' is not a directory.")
        sys.exit(1)

    print(f"📁 Project: {project_path}")
    print(f"📝 Output:  {args.output}")
    print(f"🎨 Format:  {args.format}")
    print()

    # Step 1: Scan the codebase
    print("🔍 Scanning codebase...")
    scanner = CodeScanner(project_path, forced_lang=args.lang)
    scan_result = scanner.scan()

    print(f"   Found {scan_result['file_count']} files in {scan_result['lang']} project")
    if args.verbose:
        for f in scan_result["files"]:
            print(f"   → {f['path']}")

    # Step 2: Generate documentation with AI
    print("\n🤖 Generating documentation with AI...")
    generator = DocGenerator(api_key=api_key, model=args.model, verbose=args.verbose)
    # BUG FIX: removed `output_format=args.format` — generate() never used
    # that parameter. Format is handled solely by DocWriter below.
    docs = generator.generate(
        scan_result,
        readme_only=args.readme_only,
        add_comments=args.comments,
    )

    if args.dry_run:
        print("\n📋 DRY RUN — Files that would be generated:")
        for doc in docs:
            print(f"   ✓ {doc['filename']}")
        print("\nRun without --dry-run to write files.")
        return

    # Step 3: Write output files
    print(f"\n💾 Writing documentation...")
    writer = DocWriter(output_dir=args.output, fmt=args.format)
    written = writer.write(docs)

    # Summary
    print(f"\n✅ Done! Generated {len(written)} files:")
    for f in written:
        print(f"   📄 {f}")

    print(f"\n🎉 Documentation saved to: {args.output}")
    if args.format == "html":
        print(f"   Open: {args.output}/index.html")


if __name__ == "__main__":
    main()
