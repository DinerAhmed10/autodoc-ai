"""
DocWriter: Writes generated documentation to disk.
"""

# BUG FIX: removed unused `import os`
import json
from pathlib import Path
from typing import List, Dict, Any


HTML_WRAPPER = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         max-width: 900px; margin: 40px auto; padding: 0 20px; color: #24292f; }}
  pre {{ background: #f6f8fa; border-radius: 6px; padding: 16px; overflow-x: auto; }}
  code {{ font-family: 'SF Mono', Consolas, monospace; font-size: 85%; }}
  h1 {{ border-bottom: 1px solid #d0d7de; padding-bottom: 10px; }}
  h2 {{ border-bottom: 1px solid #d0d7de; padding-bottom: 6px; }}
  a {{ color: #0969da; }}
  blockquote {{ border-left: 4px solid #d0d7de; margin: 0; padding-left: 16px; color: #57606a; }}
  table {{ border-collapse: collapse; width: 100%; }}
  th, td {{ border: 1px solid #d0d7de; padding: 8px 12px; }}
  th {{ background: #f6f8fa; }}
  ul {{ padding-left: 1.5em; }}
</style>
</head>
<body>
{body}
</body>
</html>"""


class DocWriter:
    def __init__(self, output_dir: str, fmt: str = "markdown"):
        self.output_dir = Path(output_dir)
        self.fmt = fmt

    def write(self, docs: List[Dict[str, Any]]) -> List[str]:
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # BUG FIX: JSON handling was inside the for-loop, causing it to
        # return on the very first iteration and incorrectly including
        # commented_source files in the JSON output.
        # Now handled upfront, before the loop.
        if self.fmt == "json":
            json_path = self.output_dir / "docs.json"
            all_docs = {
                d["filename"]: d["content"]
                for d in docs
                if d["type"] != "commented_source"
            }
            json_path.write_text(json.dumps(all_docs, indent=2), encoding="utf-8")
            return [str(json_path)]

        written = []

        for doc in docs:
            if doc["type"] == "commented_source":
                # Write back to source-like structure under docs/commented/
                out_path = self.output_dir / "commented" / doc["filename"]
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(doc["content"], encoding="utf-8")
            elif self.fmt == "html":
                filename = doc["filename"].replace(".md", ".html")
                out_path = self.output_dir / filename
                html_body = self._md_to_basic_html(doc["content"])
                title = doc["filename"].replace(".md", "").replace("-", " ")
                html = HTML_WRAPPER.format(title=title, body=html_body)
                out_path.write_text(html, encoding="utf-8")
            else:  # markdown (default)
                out_path = self.output_dir / doc["filename"]
                out_path.write_text(doc["content"], encoding="utf-8")

            written.append(str(out_path))

        # Create index if HTML
        if self.fmt == "html":
            self._write_html_index(docs)
            written.append(str(self.output_dir / "index.html"))

        return written

    def _md_to_basic_html(self, md: str) -> str:
        """Very basic Markdown → HTML conversion."""
        import re
        lines = md.splitlines()
        html_lines = []
        in_code = False
        in_list = False  # BUG FIX: was declared but never actually used

        for line in lines:
            # ── Code block toggle ──────────────────────────────────────────
            if line.startswith("```"):
                if in_code:
                    html_lines.append("</code></pre>")
                    in_code = False
                else:
                    # BUG FIX: close any open list before starting a code block
                    if in_list:
                        html_lines.append("</ul>")
                        in_list = False
                    lang = line[3:].strip()
                    # BUG FIX: escape lang to prevent XSS via crafted fence markers
                    lang_safe = self._escape_html(lang)
                    html_lines.append(f'<pre><code class="language-{lang_safe}">')
                    in_code = True
                continue

            if in_code:
                html_lines.append(self._escape_html(line))
                continue

            # ── Inline Markdown substitutions ──────────────────────────────
            line = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', line)
            line = re.sub(r'\*(.+?)\*', r'<em>\1</em>', line)
            line = re.sub(r'`(.+?)`', r'<code>\1</code>', line)
            line = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', line)

            # ── Block-level elements ───────────────────────────────────────
            if line.startswith("# "):
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
                html_lines.append(f"<h1>{line[2:]}</h1>")

            elif line.startswith("## "):
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
                html_lines.append(f"<h2>{line[3:]}</h2>")

            elif line.startswith("### "):
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
                html_lines.append(f"<h3>{line[4:]}</h3>")

            elif line.startswith("- ") or line.startswith("* "):
                # BUG FIX: open <ul> on first list item, keep it open for
                # consecutive items, close it when a non-list line appears.
                if not in_list:
                    html_lines.append("<ul>")
                    in_list = True
                html_lines.append(f"<li>{line[2:]}</li>")

            elif line.startswith("> "):
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
                html_lines.append(f"<blockquote>{line[2:]}</blockquote>")

            elif line.strip() == "":
                # Empty line closes an open list
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
                html_lines.append("<br>")

            else:
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
                html_lines.append(f"<p>{line}</p>")

        # BUG FIX: close any tags still open at end of document
        if in_list:
            html_lines.append("</ul>")
        if in_code:
            html_lines.append("</code></pre>")

        return "\n".join(html_lines)

    def _escape_html(self, text: str) -> str:
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def _write_html_index(self, docs: List[Dict[str, Any]]):
        links = "\n".join([
            f'<li><a href="{d["filename"].replace(".md", ".html")}">{d["filename"]}</a></li>'
            for d in docs if d["type"] != "commented_source"
        ])
        html = HTML_WRAPPER.format(
            title="Documentation",
            body=f"<h1>📚 Documentation</h1><ul>{links}</ul><p>Generated by <strong>AutoDoc-AI</strong></p>"
        )
        (self.output_dir / "index.html").write_text(html, encoding="utf-8")
