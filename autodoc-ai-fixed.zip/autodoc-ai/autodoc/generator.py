"""
DocGenerator: Uses Claude AI to generate documentation from scanned code.
"""

from typing import Dict, Any, List


README_PROMPT = """You are an expert technical writer. Analyze this codebase and generate a comprehensive, beautiful README.md.

Project: {project_name}
Language: {lang}
Files: {file_count} source files

Metadata found:
{metadata_summary}

Source files summary:
{files_summary}

Generate a README.md that includes:
1. # Project Name — with a one-line tagline
2. ## Overview — what this project does (2-3 paragraphs)  
3. ## Features — bullet list of key features
4. ## Installation — step-by-step install instructions for this language/ecosystem
5. ## Quick Start — a minimal working example with code blocks
6. ## Usage — detailed usage with multiple examples
7. ## API Reference — document the main functions/classes/endpoints
8. ## Configuration — any config options
9. ## Contributing — how to contribute
10. ## License — MIT license placeholder

Make it engaging, professional, and genuinely useful. Use emojis sparingly for visual appeal.
Output ONLY the markdown content, no extra commentary."""


API_DOCS_PROMPT = """Analyze these source files and generate detailed API documentation.

Project: {project_name}
Language: {lang}

Source files:
{files_content}

For each public function/class/method/endpoint, document:
- Name and signature
- Description of what it does
- Parameters with types and descriptions
- Return value with type and description
- Example usage
- Any exceptions/errors raised

Format as clean Markdown with proper code blocks.
Output ONLY the markdown content."""


COMMENTS_PROMPT = """Add helpful inline comments to this {lang} code file.

File: {filepath}

```{lang}
{content}
```

Rules:
- Add comments ABOVE complex logic, not obvious code
- Explain WHY, not what
- Keep comments concise (1 line max each)
- Don't comment every line — only where it adds value
- Preserve all original code exactly

Output ONLY the commented code, no explanations."""


class DocGenerator:
    def __init__(self, api_key: str, model: str = "claude-opus-4-5-20251101", verbose: bool = False):
        # BUG FIX: was "claude-opus-4-5" (invalid — missing date suffix).
        # Correct model string is "claude-opus-4-5-20251101".
        try:
            import anthropic
        except ImportError:
            raise ImportError(
                "anthropic package is required. Install it with: pip install anthropic"
            )
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model
        self.verbose = verbose

    def generate(
        self,
        scan_result: Dict[str, Any],
        readme_only: bool = False,
        add_comments: bool = False,
        # BUG FIX: removed unused `output_format` parameter.
        # Format is handled exclusively by DocWriter, not by this method.
    ) -> List[Dict[str, Any]]:
        docs = []

        # Always generate README
        print("   → Generating README.md...")
        readme = self._generate_readme(scan_result)
        docs.append({"filename": "README.md", "content": readme, "type": "readme"})

        if not readme_only:
            # Generate API docs
            print("   → Generating API documentation...")
            api_docs = self._generate_api_docs(scan_result)
            docs.append({"filename": "API.md", "content": api_docs, "type": "api"})

            # Generate CHANGELOG template
            print("   → Generating CHANGELOG template...")
            changelog = self._generate_changelog(scan_result)
            docs.append({"filename": "CHANGELOG.md", "content": changelog, "type": "changelog"})

            # Generate CONTRIBUTING guide
            print("   → Generating CONTRIBUTING.md...")
            contributing = self._generate_contributing(scan_result)
            docs.append({"filename": "CONTRIBUTING.md", "content": contributing, "type": "contributing"})

        # Add inline comments if requested
        if add_comments:
            print("   → Adding inline comments to source files...")
            for file_info in scan_result["files"][:10]:  # Limit to first 10 files
                if self.verbose:
                    print(f"      Commenting: {file_info['path']}")
                commented = self._add_comments(file_info)
                docs.append({
                    "filename": file_info["path"],
                    "content": commented,
                    "type": "commented_source"
                })

        return docs

    def _call_claude(self, prompt: str, max_tokens: int = 4000) -> str:
        message = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text

    def _generate_readme(self, scan: Dict[str, Any]) -> str:
        # Summarize files (truncate for prompt size)
        files_summary = "\n".join([
            f"- {f['path']} ({f['lines']} lines)"
            for f in scan["files"][:30]
        ])

        meta = scan.get("metadata", {})
        metadata_summary = "\n".join([
            f"[{k}]\n{v[:500]}\n"
            for k, v in meta.items()
        ])

        prompt = README_PROMPT.format(
            project_name=scan["project_name"],
            lang=scan["lang"],
            file_count=scan["file_count"],
            metadata_summary=metadata_summary or "None found",
            files_summary=files_summary,
        )
        return self._call_claude(prompt, max_tokens=4000)

    def _generate_api_docs(self, scan: Dict[str, Any]) -> str:
        # Take the most important files (main files, limited content)
        important_files = []
        total_chars = 0
        max_chars = 8000

        for f in scan["files"]:
            if total_chars >= max_chars:
                break
            snippet = f["content"][:500]
            important_files.append(f"### {f['path']}\n```{f['lang']}\n{snippet}\n```")
            total_chars += len(snippet)

        files_content = "\n\n".join(important_files)

        prompt = API_DOCS_PROMPT.format(
            project_name=scan["project_name"],
            lang=scan["lang"],
            files_content=files_content,
        )
        return self._call_claude(prompt, max_tokens=3000)

    def _generate_changelog(self, scan: Dict[str, Any]) -> str:
        prompt = f"""Generate a CHANGELOG.md template for a {scan['lang']} project called '{scan["project_name"]}'.

Use the Keep a Changelog format (https://keepachangelog.com).
Include placeholder v1.0.0 entry with common categories.
Output ONLY the markdown content."""
        return self._call_claude(prompt, max_tokens=1000)

    def _generate_contributing(self, scan: Dict[str, Any]) -> str:
        prompt = f"""Generate a CONTRIBUTING.md guide for a {scan['lang']} project called '{scan["project_name"]}'.

Include:
- How to set up the dev environment
- Coding standards for {scan['lang']}
- How to run tests
- Pull request process
- Code of conduct summary

Output ONLY the markdown content."""
        return self._call_claude(prompt, max_tokens=2000)

    def _add_comments(self, file_info: Dict[str, Any]) -> str:
        content = file_info["content"]
        # Only send the first 3000 chars to the prompt (API context limit).
        # BUG FIX: previously the truncated commented output was written as
        # the full file, silently discarding everything after char 3000.
        # Now we append the un-commented remainder so no code is lost.
        prompt = COMMENTS_PROMPT.format(
            lang=file_info["lang"],
            filepath=file_info["path"],
            content=content[:3000],
        )
        commented_portion = self._call_claude(prompt, max_tokens=2000)

        if len(content) > 3000:
            # Preserve the rest of the file exactly as-is
            commented_portion += "\n" + content[3000:]

        return commented_portion
