"""AutoDoc-AI: AI-powered documentation generator for any codebase."""

__version__ = "1.0.0"
__author__ = "AutoDoc-AI Contributors"
__license__ = "MIT"
