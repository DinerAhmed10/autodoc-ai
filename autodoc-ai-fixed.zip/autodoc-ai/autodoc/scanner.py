"""
CodeScanner: Scans a project directory and extracts relevant source files.
"""

import os
from pathlib import Path
from typing import Optional, List, Dict, Any


LANGUAGE_MAP = {
    ".py": "python",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".jsx": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".rb": "ruby",
    ".php": "php",
    ".cpp": "cpp",
    ".c": "c",
    ".cs": "csharp",
    ".swift": "swift",
    ".kt": "kotlin",
    ".scala": "scala",
    ".sh": "bash",
    ".r": "r",
    # NOTE: ".R" removed — ext is always lowercased before lookup,
    # so ".R" could never match. ".r" above already handles R files.
}

# Files/dirs to skip
IGNORE_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env",
    ".env", "dist", "build", ".next", ".nuxt", "coverage", ".pytest_cache",
    ".mypy_cache", "vendor", "target", ".cargo", "bin", "obj",
}

IGNORE_FILES = {
    ".DS_Store", "Thumbs.db", ".gitignore", ".gitattributes",
    "package-lock.json", "yarn.lock", "poetry.lock", "Pipfile.lock",
}

MAX_FILE_SIZE_KB = 100  # Skip files larger than this


class CodeScanner:
    def __init__(self, path: Path, forced_lang: Optional[str] = None):
        self.path = path
        self.forced_lang = forced_lang

    def scan(self) -> Dict[str, Any]:
        files = []
        lang_counts: Dict[str, int] = {}

        for root, dirs, filenames in os.walk(self.path):
            # Prune ignored directories
            dirs[:] = [d for d in dirs if d not in IGNORE_DIRS and not d.startswith(".")]

            for filename in filenames:
                if filename in IGNORE_FILES:
                    continue

                filepath = Path(root) / filename
                ext = filepath.suffix.lower()

                if ext not in LANGUAGE_MAP:
                    continue

                # Skip large files
                try:
                    size_kb = filepath.stat().st_size / 1024
                    if size_kb > MAX_FILE_SIZE_KB:
                        continue
                except OSError:
                    continue

                lang = LANGUAGE_MAP[ext]
                lang_counts[lang] = lang_counts.get(lang, 0) + 1

                try:
                    content = filepath.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    continue

                relative = filepath.relative_to(self.path)
                files.append({
                    "path": str(relative),
                    "lang": lang,
                    "content": content,
                    "lines": len(content.splitlines()),
                })

        # Detect primary language
        if self.forced_lang:
            primary_lang = self.forced_lang
        elif lang_counts:
            primary_lang = max(lang_counts, key=lang_counts.get)
        else:
            primary_lang = "unknown"

        # Also gather project metadata
        metadata = self._gather_metadata()

        return {
            "project_name": self.path.name,
            "project_path": str(self.path),
            "lang": primary_lang,
            "lang_breakdown": lang_counts,
            "file_count": len(files),
            "files": files,
            "metadata": metadata,
        }

    def _gather_metadata(self) -> Dict[str, Any]:
        meta = {}

        # Check for common config files
        config_files = [
            "package.json", "pyproject.toml", "setup.py", "Cargo.toml",
            "go.mod", "pom.xml", "build.gradle", "composer.json",
            "Gemfile", "requirements.txt", "README.md",
        ]

        for cf in config_files:
            fp = self.path / cf
            if fp.exists():
                try:
                    meta[cf] = fp.read_text(encoding="utf-8", errors="ignore")[:2000]
                except Exception:
                    pass

        return meta
